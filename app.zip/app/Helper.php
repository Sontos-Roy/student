<?php

use App\Models\User;
use Illuminate\Support\Facades\Storage;

if (!function_exists('getSetting')) {
    function getSetting($key){
        $setting=\Cache::get('settings');
        return $setting[$key]??'';
    }
}
function getNotifications(){
    $user = auth()->guard('admin')->user();
    $data = $user->notifications()->latest()->get();
    return $data;
}
function getStudentNotifications(){
    $user = auth()->user();
    $data = $user->notifications()->latest()->get();
    return $data;
}

function getImage($folder=null,$file=null, $null = null){

    if($null){
        $defaultImage = '';
    }else{
        $defaultImage = 'nothing.png';
    }

    if (!empty($folder) && !empty($file)) {
        $path = 'images/' . $folder . '/' . $file;
            return asset(Storage::url($path));
    }

    return asset(Storage::url($defaultImage));

}

function deleteImage($folder=null, $file=null){
    if (!empty($folder) && !empty($file)) {
        $imagePath = 'images/'.$folder.'/' . $file;

            Storage::disk('public')->delete($imagePath);
    }
    return true;
}


function createImage($request, $folder){
    $image = $request->file('image');
    $filename = time().'_'.$image->getClientOriginalName();
    $image->storeAs('public/images/'.$folder, $filename);
    return $filename;
}

function createImage2($request, $name, $folder){
    $image = $request->file($name);
    $filename = time().'_'.$image->getClientOriginalName();
    $image->storeAs('public/images/'.$folder, $filename);
    return $filename;
}

function getCompletion($id){
    $user = User::find($id);
    $completionCriteria = [
        'name' => 5,
        'email' => 5,
        'two_factor' => 10,
        'nid' => 5,
        'registration_no' => 5,
        'address' => 5,
        'phone' => 10,
        'father_name' => 5,
        'mother_name' => 5,
        'dob' => 5,
        'nationality' => 5,
        'image' => 10,
        'signature' => 10,
        'gender' => 5,
        'session' => 10
    ];

    $totalWeight = array_sum($completionCriteria);
    $completedWeight = 0;
    foreach ($completionCriteria as $field => $weight) {
        if (!empty($user->{$field})) {
            $completedWeight += $weight;
        }
    }
    $completionPercentage = ($completedWeight / $totalWeight) * 100;
    $completionPercentage = floor($completionPercentage);
    return $completionPercentage;
}

?>
