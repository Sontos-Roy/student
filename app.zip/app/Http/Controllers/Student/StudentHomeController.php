<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Notification as ModelsNotification;
use Illuminate\Http\Request;
use Illuminate\Notifications\Notification;

class StudentHomeController extends Controller
{
    function index(){
        $this->data['user'] = auth()->user();
        return view('students.dashboard.index', $this->data);
    }

    function notifications(){
        $this->data['user'] = auth()->user();
        return view('students.profile.notifications', $this->data);
    }
    function notifications_destroy($id){
        $item = ModelsNotification::find($id);
        $item->delete();
        return response()->json(['status' => true, 'msg' => 'Notification Deleted Successfully']);
    }
}
