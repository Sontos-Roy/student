<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class AdminsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Admin::orderBy('id');
        if ($request->has('search') && $request->search !== '') {
            $query->where(function($query) use ($request) {
                $query->where('name', 'LIKE', '%'.$request->search.'%')
                      ->orWhere('email', 'LIKE', '%'.$request->search.'%')
                      ->orWhere('phone', 'LIKE', '%'.$request->search.'%');
            });
        }
        $this->data['roles'] = Role::all();
        $this->data['users'] = $query->paginate(5);
        return view('admin.users.index', $this->data);
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' =>'required',
            'email' =>'required',
            'phone' =>'required',
            'phone' =>'required | min:6',
        ]);
        $request->validate([
            'user_role'=>'required'
        ]);
        $admin->assignRole('admin');
        $data['password'] = bcrypt($request->password);
        if($request->hasFile('image')){
            $data['image'] = createImage($request, 'admins');
        }
        Admin::create($data);
        return response()->json(['status' => true, 'msg' => 'User Created Successfully']);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $this->data['user'] = Admin::find($id);
        $html = view('admin.users.edit', $this->data)->render();
        return response()->json(['status' => true, 'html' => $html]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $data = Admin::find($id);
        if($data->image){
            deleteImage('admins', $data->image);
        }
        $data->delete();
        return response()->json(['status' => true, 'msg' => 'User Deleted Successfully']);
    }
    function deleteusers(Request $request){
        $users = $request->users;
        if(!$users){
            return response()->json(['status' => false, 'msg' => 'Please Select User First']);
        }
        foreach($users as $key => $item){
            $data = Admin::find($item);
            if($data->id == auth()->id()){

            }else{
                if($data->image){
                    deleteImage('admins', $data->image);
                }
                $data->delete();
            }
        }
        return response()->json(['status' => true, 'msg' => 'Selected Users Deleted Successfully']);
    }
}
