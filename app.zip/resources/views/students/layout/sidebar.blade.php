<div class="menu menu-column menu-rounded menu-sub-indention fw-semibold fs-6" id="#kt_app_sidebar_menu"
    data-kt-menu="true" data-kt-menu-expand="false">
    <!--begin:Menu item-->
    <div class="menu-item"><!--begin:Menu link-->
        <a class="menu-link {{ in_array($currentUrl, ['students.dashboard']) ? 'active' : '' }}" href="{{route('students.dashboard')}}">
            <span class="menu-icon">
                <i class="ki-duotone ki-user fs-2">
                    <span class="path1"></span>
                    <span class="path2"></span>
                </i>
            </span>
            <span class="menu-title">Profile</span>
        </a><!--end:Menu link-->
    </div>
    <!--end:Menu item-->
    <div class="menu-item pt-5"><!--begin:Menu content-->
        <div class="menu-content"><span class="menu-heading fw-bold text-uppercase fs-7">Applications</span></div>
    </div>
    <div class="menu-item">
        <a class="menu-link modal_btn {{ in_array($currentUrl, ['students.clearence.create']) ? 'active' : '' }}" href="{{route('students.clearence.index')}}">
            <span class="menu-icon">
                <i class="ki-duotone ki-user fs-2">
                    <span class="path1"></span>
                    <span class="path2"></span>
                </i>
            </span>
            <span class="menu-title">Apply for Clearence</span>
        </a>
    </div>
</div>
