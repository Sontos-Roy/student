<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column flex-column-fluid">

        <!--begin::Toolbar-->
        <div id="kt_app_content" class="app-content  flex-column-fluid ">


            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container  container-xxl ">

                <!--begin::Navbar-->
                <?php echo $__env->make('students.layout.profile_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('students.profile.partials.allNotifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Toolbar-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/js/custom/account/settings/signin-methods.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/account/settings/profile-details.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/account/settings/deactivate-account.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom/pages/user-profile/general.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.students.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xmapp\htdocs\student\resources\views/students/profile/notifications.blade.php ENDPATH**/ ?>