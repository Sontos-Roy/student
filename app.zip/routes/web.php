<?php

use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminsController;
use App\Http\Controllers\Admin\AdminStudentControler;
use App\Http\Controllers\Admin\DegreeController;
use App\Http\Controllers\Admin\PermissionsController;
use App\Http\Controllers\Admin\RolesController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\AdminNotificationController;
use App\Http\Controllers\Student\ClearanceController;
use App\Http\Controllers\Student\StudentAuthController;
use App\Http\Controllers\Student\StudentHomeController;
use App\Http\Controllers\Student\StudentProfileController;
use App\Notifications\AuthNotification;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification as FacadesNotification;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [StudentAuthController::class, 'index'])->name('student.index');
Route::post('/student-login', [StudentAuthController::class, 'login'])->name('student.login');
Route::get('/student-register', [StudentAuthController::class, 'register'])->name('student.register');
Route::post('/student-register', [StudentAuthController::class, 'register_store'])->name('student.register.store');
Route::get('/student-validation', [StudentAuthController::class, 'otp'])->name('student.otp');
Route::get('/forget-password', [StudentAuthController::class, 'forget_password'])->name('student.forget.password');
Route::get('/forget-password-otp', [StudentAuthController::class, 'forget_password_otp'])->name('student.forget.password.otp');
Route::post('/forget-password-otp', [StudentAuthController::class, 'forget_password_otp_store'])->name('student.forget.password.otp.store');
Route::post('/forget-password', [StudentAuthController::class, 'forget_password_store'])->name('student.forget.password.store');
Route::post('/student-otp-verify', [StudentAuthController::class, 'otp_store'])->name('student.otp.verify');
Route::get('/student-otp-resent', [StudentAuthController::class, 'resend'])->name('student.otp.resend');
Route::get('/two-factor', [StudentAuthController::class, 'two_factor_login'])->name('student.two.factor.login');
Route::post('/two-factor', [StudentAuthController::class, 'two_factor_login_store'])->name('student.two.factor.login.store');
Route::get('student-logout', [StudentAuthController::class, 'logout'])->name('student.logout');

Route::get('admin-login', [AdminAuthController::class, 'login'])->name('admin.login');
Route::post('admin-login', [AdminAuthController::class, 'login_store'])->name('admin.login.store');
Route::get('admin-signup', [AdminAuthController::class, 'signup'])->name('admin.signup');
Route::post('admin-signup', [AdminAuthController::class, 'signup_store'])->name('admin.signup.store');
Route::get('admin-logout', [AdminAuthController::class, 'logout'])->name('admin.logout');
Route::get('notification', function(){
    if (auth()->guard('admin')->check()) {
        FacadesNotification::send(auth()->guard('admin')->user(), new AuthNotification());
    } else {
        dd('not');
    }
});
Route::group(['middleware' => 'admin', 'as' => 'admin.', 'prefix'=>'admin'], function(){
    Route::get('dashboard', [AdminAuthController::class, 'index'])->name('dashboard');
    Route::resource('notifications', AdminNotificationController::class);
    Route::resource('students', AdminStudentControler::class);
    Route::post('student-import', [AdminStudentControler::class, 'userImport'])->name('student.import');
    Route::delete('delete_students', [AdminStudentControler::class, 'deleteStudents'])->name('delete.students');
    Route::delete('delete_users', [AdminsController::class, 'deleteusers'])->name('delete.users');
    Route::resource('manage-users', AdminsController::class, ['names' => 'manage.users']);
    Route::resource('permissions', PermissionsController::class, ['names' => 'permissions']);
    Route::resource('roles', RolesController::class, ['names' => 'roles']);
    Route::resource('settings', SettingController::class, ['names' => 'settings']);
    Route::resource('degree', DegreeController::class, ['names' => 'degree']);
});

Route::group(['middleware' => 'auth', 'as' => 'students.', 'prefix' => 'students'], function(){
    Route::get('/set_password', [StudentAuthController::class, 'password'])->name('password');
    Route::post('/set_password', [StudentAuthController::class, 'password_store'])->name('password.store');
    Route::get('overview', [StudentHomeController::class, 'index'])->name('dashboard');
    Route::get('notifications', [StudentHomeController::class, 'notifications'])->name('notifications');
    Route::delete('notifications/destroy/{id}', [StudentHomeController::class, 'notifications_destroy'])->name('notifications.destroy');
    Route::get('profile', [StudentProfileController::class, 'Profile'])->name('profile');
    Route::get('profile/edit', [StudentProfileController::class, 'edit'])->name('profile.edit');
    Route::post('profile/edit', [StudentProfileController::class, 'edit_store'])->name('profile.edit.store');
    Route::get('profile/settings', [StudentProfileController::class, 'settings'])->name('profile.settings');
    Route::get('profile/security', [StudentProfileController::class, 'security'])->name('profile.security');
    Route::post('change_phone', [StudentProfileController::class, 'change_phone'])->name('change.phone');
    Route::post('change_password', [StudentProfileController::class, 'change_password'])->name('change.password');
    Route::get('get_otp', [StudentProfileController::class, 'getOtp'])->name('getOtp.two.factor');
    Route::post('enable_otp', [StudentProfileController::class, 'enable_otp'])->name('enable.two.factor');
    Route::delete('deactive_user/{id}', [StudentProfileController::class, 'deactive_user'])->name('deactive.user');
    Route::get('clearence', [ClearanceController::class, 'index'])->name('clearence.index');
    Route::post('clearence/store', [ClearanceController::class, 'get_store'])->name('clearence.get.store');
    Route::get('clearence/apply', [ClearanceController::class, 'create'])->name('clearence.create');
    Route::post('clearence/apply', [ClearanceController::class, 'store'])->name('clearence.store');
});
